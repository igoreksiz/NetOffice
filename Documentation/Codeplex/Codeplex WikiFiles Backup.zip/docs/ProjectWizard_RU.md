#### Мастер создания проекта
NetOffice предлагает мастер создания проектов в виде расширения Visual Studio. Visual Studio Express не поддерживает расширения. Пользователи VS Express могут воспользоваться «Мастером создания проекта», входящего в состав отдельного приложения «Developer Toolbox». Программа генерирует решение в формате VS Express.

![](ProjectWizard_RU_http://download.codeplex.com/Download?ProjectName=netoffice&DownloadId=369832)

Нажмите на кнопку "New Project" и выберите язык программирования и версию Visual Studio Expess.

![](ProjectWizard_RU_http://download.codeplex.com/Download?ProjectName=netoffice&DownloadId=369766)

После завершения работы "Мастер создания проекта" откроет папку решения в Проводнике. Это решение можно открыть в Visual Studio Express.
