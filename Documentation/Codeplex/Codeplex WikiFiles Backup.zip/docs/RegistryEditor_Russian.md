##### Registry editor
Это средство внешне и технически является копией редактора реестра Windows, но работает лишь с разделами приложений Office. NetOffice Registry Editor позволяет быстрее и проще проверить или изменить параметры приложения Office.

![](RegistryEditor_Russian_http://download.codeplex.com/Download?ProjectName=netoffice&DownloadId=295194)

Все диалоги и функции работают так же, как и в редакторе реестра Windows. Если у вас нет прав администратора, NetOffice Registry editor не даёт возможности изменять разделы или параметры в корневом разделе HKEY_LOCAL_MACHINE.